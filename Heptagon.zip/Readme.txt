=============
?Heptagon.exe?
=============

Made By Minhgotuknight19

Created: April 11 2024
Made In C++
Dont RUN your PC

This Is Non-Safety Run Malware

Credits To GetMBR For Hue Functions

-------------------------------------------------------
see the Triangles:

 Heptagon

Url: htpps://www.twinkl.com.vn/teaching-wiki/heptagon
-------------------------------------------------------

scroll down :)



scroll down :\





scroll down :/




scroll down :|









Hi I am Wynn and Yedb0y33k